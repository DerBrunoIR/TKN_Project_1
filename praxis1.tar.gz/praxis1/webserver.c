#include <stdlib.h>


int main(int argc, char** argv) {
    // Start here :)
    return EXIT_SUCCESS;
}
